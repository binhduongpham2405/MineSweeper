import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class MinesweeperGUI extends JFrame {
    private JButton[][] buttons;
    private ImageIcon mineIcon;
    private char[][] board;
    private boolean[][] revealed;
    private int rows;
    private int cols;
    private int mines;

    public MinesweeperGUI(int rows, int cols, int mines) {
        this.rows = rows;
        this.cols = cols;
        this.mines = mines;
        this.board = new char[rows][cols];
        this.revealed = new boolean[rows][cols];
        initializeBoard();
        placeMines();

        setTitle("Minesweeper");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(50 * cols, 50 * rows);
        setLayout(new GridLayout(rows, cols));

        buttons = new JButton[rows][cols];
        mineIcon = new ImageIcon("mine.png"); 
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                buttons[i][j] = new JButton();
                buttons[i][j].setPreferredSize(new Dimension(50, 50));
                int row = i, col = j;
                buttons[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        reveal(row, col);
                    }
                });
                add(buttons[i][j]);
            }
        }

        setVisible(true);
    }

    private void initializeBoard() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                board[i][j] = '.';
                revealed[i][j] = false;
            }
        }
    }

    private void placeMines() {
        Random rand = new Random();
        int count = 0;
        while (count < mines) {
            int row = rand.nextInt(rows);
            int col = rand.nextInt(cols);
            if (board[row][col] != '*') {
                board[row][col] = '*';
                count++;
            }
        }
    }

    private void reveal(int row, int col) {
        if (board[row][col] == '*') {
            JOptionPane.showMessageDialog(this, "Game Over! You hit a mine.");
            revealAllMines();
            return;
        }
        revealCell(row, col);
        if (board[row][col] == '0') {
            revealNeighbors(row, col);
        }
        updateUI();
        if (checkWin()) {
            JOptionPane.showMessageDialog(this, "Congratulations! You win!");
        }
    }

    private void revealCell(int row, int col) {
        revealed[row][col] = true;
    }

    private void revealNeighbors(int row, int col) {
        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                if (i >= 0 && i < rows && j >= 0 && j < cols && !revealed[i][j]) {
                    reveal(i, j);
                }
            }
        }
    }

    private void updateUI() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (revealed[i][j]) {
                    if (board[i][j] == '*') {
                        buttons[i][j].setIcon(mineIcon);
                    } else {
                        buttons[i][j].setText(Character.toString(board[i][j]));
                    }
                    buttons[i][j].setEnabled(false);
                }
            }
        }
    }

    private void revealAllMines() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (board[i][j] == '*') {
                    buttons[i][j].setIcon(mineIcon);
                }
                buttons[i][j].setEnabled(false);
            }
        }
    }

    private boolean checkWin() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (board[i][j] != '*' && !revealed[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MinesweeperGUI(10, 10, 10);
        });
    }
}
