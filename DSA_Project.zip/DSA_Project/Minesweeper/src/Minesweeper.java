import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class Minesweeper {
    private class MineTile extends JButton {
        int r;
        int c;

        public MineTile(int r, int c) {
            this.r = r;
            this.c = c;
        }
    }

    int titleSize = 90;
    int numRows = 8;
    int numCols = numRows;
    int boardWidth = numCols * titleSize;
    int boardHeight = numRows * titleSize;

    JFrame frame = new JFrame("Minesweeper");
    JLabel textLabel = new JLabel();
    JPanel textPanel = new JPanel();
    JPanel boardPanel = new JPanel();
    int minesCount = 1;

    MineTile[][] board = new MineTile[numRows][numCols];
    ArrayList<MineTile> mineList;
    Random random = new Random();

    ImageIcon bombIcon;
    ImageIcon flagIcon;

    int tilesClicked = 0;
    boolean gameOver = false;

    JButton restartButton; // Restart button

    Minesweeper() {
        frame.setSize(boardWidth, boardHeight);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Load images and resize
        bombIcon = resizeImageIcon("bomb.png", 35, 35);
        flagIcon = resizeImageIcon("flag.png", 35, 35);

        textLabel.setFont(new Font("Arial", Font.BOLD, 25));
        textLabel.setHorizontalAlignment(JLabel.CENTER);
        textLabel.setText("Minesweeper: " + Integer.toString(minesCount));
        textLabel.setOpaque(true);
        textPanel.setLayout(new BorderLayout());
        textPanel.add(textLabel);
        // Create restart button
        restartButton = new JButton("Restart");
        restartButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                restartGame();
            }
        });
        textPanel.add(restartButton, BorderLayout.EAST); // Add restart button to text panel
        frame.add(textPanel, BorderLayout.NORTH);
        boardPanel.setLayout(new GridLayout(numRows, numCols));
        frame.add(boardPanel);

        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                MineTile tile = new MineTile(r, c);
                board[r][c] = tile;
                tile.setFocusable(false);
                tile.setMargin(new Insets(0, 0, 0, 0));
                tile.setFont(new Font("Arial", Font.PLAIN, 45));
                tile.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(MouseEvent e) {
                        if (gameOver) {
                            return;
                        }
                        MineTile tile = (MineTile) e.getSource();

                        if (e.getButton() == MouseEvent.BUTTON1) {
                            if (tile.getText() == "") {
                                if (mineList.contains(tile)) {
                                    revealMines();
                                } else {
                                    checkMine(tile.r, tile.c);
                                }
                            }
                        } else if (e.getButton() == MouseEvent.BUTTON3) {
                            if (tile.getText() == "" && tile.isEnabled()) {
                                tile.setIcon(flagIcon);
                            } else if (tile.getIcon() == flagIcon) {
                                tile.setIcon(null);
                            }
                        }
                    }
                });

                boardPanel.add(tile);
            }

        }
        frame.setVisible(true);
        setMines();
    }

    void setMines() {
        mineList = new ArrayList<MineTile>();
        int mineLeft = minesCount;
        while (mineLeft > 0) {
            int r = random.nextInt(numRows);
            int c = random.nextInt(numCols);
            // int r = 2;
            // int c = 2;

            MineTile tile = board[r][c];
            if (!mineList.contains(tile)) {
                mineList.add(tile);
                mineLeft -= 1;
            }
        }

    }

    void revealMines() {
        for (int index = 0; index < mineList.size(); index++) {
            MineTile tile = mineList.get(index);
            tile.setIcon(bombIcon);
        }
        gameOver = true;
        textLabel.setText("Game Over!!!!!");
    }

    void checkMine(int r, int c) {
        if (r < 0 || r >= numRows || c < 0 || c >= numCols) {
            return;
        }

        MineTile tile = board[r][c];
        if (!tile.isEnabled()) {
            return;

        }
        tile.setEnabled(false);
        tilesClicked += 1;

        int minesFound = 0;


        minesFound += countMines(r - 1, c - 1);//top left
        minesFound += countMines(r - 1, c);//top
        minesFound += countMines(r - 1, c + 1);//top right

        //Left and Right
        minesFound += countMines(r, c + 1);
        minesFound += countMines(r, c - 1);
        //bottom 3
        minesFound += countMines(r + 1, c - 1);//bottom Left
        minesFound += countMines(r + 1, c);//bottom 
        minesFound += countMines(r + 1, c + 1);//bottom Right
        if (minesFound > 0) {
            tile.setText(Integer.toString(minesFound));
        } else {
            tile.setText("");

            //top3
            checkMine(r - 1, c - 1);
            checkMine(r - 1, c);
            checkMine(r - 1, c + 1);

            checkMine(r, c - 1);
            checkMine(r, c + 1);

            checkMine(r + 1, c - 1);
            checkMine(r + 1, c + 1);
            checkMine(r + 1, c);
        }
        if (tilesClicked == numRows * numCols - mineList.size()) {
            gameOver = true;
            textLabel.setText("Mine Clear!!!!");
        }
    }

    int countMines(int r, int c) {
        if (r < 0 || r >= numRows || c < 0 || c >= numCols) {
            return 0;
        }
        if (mineList.contains(board[r][c])) {
            return 1;
        }
        return 0;
    }

    // Resize image icon to the specified width and height
    ImageIcon resizeImageIcon(String imagePath, int width, int height) {
        try {
            ImageIcon imageIcon = new ImageIcon(getClass().getResource(imagePath));
            Image image = imageIcon.getImage();
            Image resizedImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(resizedImage);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Restart the game
    void restartGame() {
        // Reset game state variables
        tilesClicked = 0;
        gameOver = false;
        textLabel.setText("Minesweeper: " + Integer.toString(minesCount));

        // Clear icons and text on all tiles
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                MineTile tile = board[r][c];
                tile.setIcon(null);
                tile.setText("");
                tile.setEnabled(true);
            }
        }

        // Set mines for a new game
        setMines();
    }
}
